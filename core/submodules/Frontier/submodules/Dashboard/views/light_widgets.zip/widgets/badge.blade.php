<v-card class="elevation-1">
    <v-card-text>
        <v-card-media
            src="{{ assets('frontier/images/badges/badge-02.png') }}"
            height="125px"
            contain
            >
        </v-card-media>
    </v-card-text>
    <v-divider></v-divider>
    <v-card-text class="text-xs-center">
        <div class="subheading"><strong>Course Completion Badge</strong></div>
        <div class="body-1 mt-1 grey--text">Complete lessons to unlock</div>
    </v-card-text>
</v-card>
