<?php

return [
    '403' => "The page is restricted.",
    '404' => "The page you requested was not found.",
];
