<?php

return [
    'admin' => 'admin',
    'modules' => 'modules',
    'public' => 'public',
    'migrations' => 'database/migrations',
    'themes' => 'themes',

    // url
    'login' => 'login',
    'logout' => 'logout',
    'register' => 'register',
    'redirect_after_logout' => 'login',
];
