<?php

return [
    'admin' => 'home',
    'create' => 'new',
];
