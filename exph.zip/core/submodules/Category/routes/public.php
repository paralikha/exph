<?php

Route::resource('categories', 'Category\Controllers\CategoryController');
