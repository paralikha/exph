<?php

namespace Frontier\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Pluma\Models\Model;

class Page extends Model
{
    use SoftDeletes;
}
