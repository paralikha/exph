# vuetify-mediabox

> A Vue.js UMD project

## Dependencies
```
"vue": "^2.4.4",
"vue-resource": "^1.3.4",
"vuetify": "^0.15.2"
```

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

## To do
* add live demo page
* ...

For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).
