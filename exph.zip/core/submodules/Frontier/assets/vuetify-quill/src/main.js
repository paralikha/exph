import Quill from './Quill.vue'

export default Quill
