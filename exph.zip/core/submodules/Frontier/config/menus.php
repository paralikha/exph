<?php

return [
    'management' => [
        'name' => 'management',
        'is_header' => true,
        'order' => 499,
        'class' => 'separator',
        'markup' => 'span',
        'text' => __('Management'),
    ],
];
