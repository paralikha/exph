<?php

Route::get('{slug?}', '\Frontier\Controllers\PublicController@show')
    ->name('public.show')
    ->where('slug', '.*');
