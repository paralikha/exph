<?php

Route::resource('appearance/menus', 'Menu\Controllers\MenuController');
