<?php

namespace Page\Support\Traits;

use Crowfeather\Traverser\Traverser;

trait PageMutators
{
    //
}
