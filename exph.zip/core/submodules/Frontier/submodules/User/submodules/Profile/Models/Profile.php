<?php

namespace Profile\Models;

use Setting\Models\Setting;

class Profile extends Setting
{
    //
}
