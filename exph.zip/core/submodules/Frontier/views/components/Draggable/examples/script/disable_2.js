var app = new Vue({
  el: '#main',
  data: {
    items: ['1', '2', '3'],
    options: {
      disabled: false
    }
  }
})