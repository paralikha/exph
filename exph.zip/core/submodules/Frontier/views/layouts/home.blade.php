@include("Theme::partials.header")

@yield("pre-content")
@yield("content")
@yield("post-content")

@include("Theme::partials.footer")
