<?php

return [
    'application/zip', 'application/rar', 'application/7z',
    'application/x-zip-compressed', 'application/x-rar-compressed', 'application/x-7z-compressed',
];
