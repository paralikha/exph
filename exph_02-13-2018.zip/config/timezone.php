<?php

return [
    'default' => env("APP_TIMEZONE", "Asia/Manila"),
];