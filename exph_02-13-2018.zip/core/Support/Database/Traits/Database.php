<?php

namespace Pluma\Support\Database\Traits;

trait Database
{
    public function __construct()
    {
        parent::__construct();
    }
}
