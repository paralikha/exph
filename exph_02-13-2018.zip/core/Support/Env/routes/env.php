<?php

// use Pluma\Support\Facades\Route;

\Illuminate\Support\Facades\Route::get('/1', function () {
    return '090';
});