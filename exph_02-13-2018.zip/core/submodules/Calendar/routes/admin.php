<?php

Route::resource('calendars', 'Calendar\Controllers\CalendarController');
