import Mediabox from './Mediabox.vue'

export default Mediabox
