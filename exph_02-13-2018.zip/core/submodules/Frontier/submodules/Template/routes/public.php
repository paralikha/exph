<?php

Route::resource('templates', 'Template\Controllers\TemplateController');
