<v-btn floating fixed bottom right fab dark ripple small class="red">
    <v-icon dark>keyboard_arrow_up</v-icon>
</v-btn>
