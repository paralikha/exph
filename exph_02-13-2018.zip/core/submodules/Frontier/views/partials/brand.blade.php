<img src="{{ $application->site->logo }}" alt="{{ __($application->site->title) }}">
