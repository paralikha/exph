<v-footer class="primary lighten-4 white--text">
    @yield('endnote')
</v-footer>
