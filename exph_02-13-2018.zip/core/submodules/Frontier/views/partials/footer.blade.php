    @stack("pre-footer")
    @stack("footer")
    @stack("post-footer")

    @stack("pre-js")
    @stack("js")
    @stack("post-js")
</body>
</html>