<!-- start search form -->
<div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
  <label class="mdl-button mdl-js-button mdl-button--icon" for="search-expandable">
    <i class="material-icons">search</i>
  </label>
  <div class="mdl-textfield__expandable-holder">
    <input class="mdl-textfield__input" type="text" id="search-expandable" />
    <label class="mdl-textfield__label" for="search-expandable">Search text</label>
  </div>
</div>
<!-- end search form -->