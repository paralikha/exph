<noscript>
    <style scoped>
        noscript {
            display: block;
            background-color: pink;
            color: #800000;
            padding: 1.5rem;
            text-align: center;
        }
    </style>
    <strong>D'oh!</strong> It seems your browser is running with javascript <strong>disabled</strong>. Please enable javascript to continue experiencing the site as intended.
</noscript>
