@extends("Frontier::layouts.home")

@section("content")

    <h1>Welcome Home</h1>

@endsection