@extends("Frontier::layouts.public")

@section("content")
    <h1>Lo</h1>
    <div class="panel">
        <div class="panel-body">
            welcome.
        </div>
    </div>
@endsection