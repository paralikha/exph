import Component from './Component.vue'

export default Component
