<?php

Route::resource('libraries', 'Library\Controllers\LibraryController');
