<?php

namespace Shop\Support\Payment;

use Shop\Support\Payment\Payment;

class PayPal extends Payment
{
    protected $payment = 'paypal';
}
