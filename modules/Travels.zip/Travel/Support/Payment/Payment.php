<?php

namespace Shop\Support\Payment;

class Payment
{
    //
}
