<?php

Route::resource('budgets', 'Budget\Controllers\BudgetController');
