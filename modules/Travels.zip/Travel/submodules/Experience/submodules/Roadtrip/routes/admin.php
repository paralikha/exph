<?php

Route::resource('roadtrips', 'Roadtrip\Controllers\RoadtripController');
